FISCH TAP HELPER — ANDROID SOURCE PROJECT

What it does
- Repeats a tap at a chosen screen coordinate.
- Lets you set the interval in milliseconds.
- Uses Android Accessibility Service gesture support.
- The user must enable the service manually in Android Settings.

Important limitations
- This ZIP is Android source code, NOT a compiled APK.
- It does not detect fish, the fishing bar, catch completion, or automatically choose when to tap.
- It simply repeats one tap at the same X/Y point.
- Android may restrict or stop background activity depending on device settings.
- Use automation only where Roblox/game rules allow it. It may not work as expected in every game or screen.

Build requirements
- Android Studio or a compatible Android IDE.
- JDK 17.
- Android SDK Platform 35.
- Gradle 8.9 or compatible Android Gradle Plugin 8.7.3.

Build
1. Open this project folder in Android Studio.
2. Let Gradle sync and download dependencies.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK will be in app/build/outputs/apk/debug/app-debug.apk.

Phone setup
1. Install the APK you built.
2. Open Fisch Tap Helper.
3. Tap "Enable Accessibility Service".
4. Find Fisch Tap Helper in Android Accessibility settings and enable it.
5. Return to the app and enter X/Y coordinates and delay.
6. Tap Save, then Start.
7. Switch to Fisch. Reopen the helper and tap Stop to stop it.

Start with a long delay and a harmless screen position. Incorrect coordinates can tap unwanted controls.
