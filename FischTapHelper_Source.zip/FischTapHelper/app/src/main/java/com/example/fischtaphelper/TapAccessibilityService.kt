package com.example.fischtaphelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { stopTapping() }

    fun startTapping() {
        if (running) return
        running = true
        tapLoop()
    }

    fun stopTapping() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun tapLoop() {
        if (!running) return
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val x = prefs.getInt("x", 500).toFloat()
        val y = prefs.getInt("y", 1500).toFloat()
        val delay = prefs.getInt("delay", 1500).toLong().coerceAtLeast(500L)

        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()

        dispatchGesture(gesture, null, null)
        handler.postDelayed({ tapLoop() }, delay)
    }

    override fun onDestroy() {
        stopTapping()
        instance = null
        super.onDestroy()
    }
}
