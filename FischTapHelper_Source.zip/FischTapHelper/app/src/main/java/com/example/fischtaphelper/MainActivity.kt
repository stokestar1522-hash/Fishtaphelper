package com.example.fischtaphelper

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var delayInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        fun label(text: String) {
            layout.addView(TextView(this).apply { this.text = text; textSize = 16f })
        }
        fun field(hint: String, value: String): EditText {
            return EditText(this).apply {
                this.hint = hint
                setSingleLine(true)
                setText(value)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                layout.addView(this)
            }
        }

        label("Fisch Tap Helper")
        label("Enter screen coordinates in pixels (X goes left-to-right, Y goes top-to-bottom).")
        xInput = field("X position", prefs.getInt("x", 500).toString())
        yInput = field("Y position", prefs.getInt("y", 1500).toString())
        label("Delay between taps (milliseconds; minimum 500)")
        delayInput = field("Delay ms", prefs.getInt("delay", 1500).toString())

        val accessibility = Button(this).apply {
            text = "1. Enable Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(accessibility)

        val save = Button(this).apply {
            text = "Save settings"
            setOnClickListener {
                val x = xInput.text.toString().toIntOrNull()
                val y = yInput.text.toString().toIntOrNull()
                val d = delayInput.text.toString().toLongOrNull()
                if (x == null || y == null || d == null || x < 0 || y < 0 || d < 500) {
                    status.text = "Enter valid X/Y values and a delay of at least 500 ms."
                } else {
                    prefs.edit().putInt("x", x).putInt("y", y).putInt("delay", d.toInt()).apply()
                    status.text = "Saved. Check the tap position before starting."
                }
            }
        }
        layout.addView(save)

        val start = Button(this).apply {
            text = "2. Start repeated taps"
            setOnClickListener {
                save.performClick()
                if (TapAccessibilityService.instance == null) {
                    status.text = "Enable the Accessibility Service first."
                } else {
                    TapAccessibilityService.instance?.startTapping()
                    status.text = "Running. Return to Fisch. Reopen this app and press Stop to end."
                }
            }
        }
        layout.addView(start)

        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener {
                TapAccessibilityService.instance?.stopTapping()
                status.text = "Stopped."
            }
        }
        layout.addView(stop)

        status = TextView(this).apply { text = "Not running."; textSize = 15f }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "Safety: use only where automation is allowed. Tapping repeats at the exact X/Y point, so test with a long delay first."
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
